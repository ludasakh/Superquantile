parpool('local',15);
rng('shuffle');

%k=1:300, n=200 in the first simulation

parfor k=1:300
%[tn, qn1, qn2]=quantreg0(600,15, zeros(15,1),2,3,3);
[tn, qn1, qn2]=quantreg0(200,15, [0.5; zeros(14,1)],2,2,2);
%[tn, qn1, qn2]=quantreg0(200,25, [0.5;zeros(24,1)],1,1,1);
%[tn, qn1, qn2]=quantreg0(200,15, [0.1*ones(10,1);zeros(5,1)],2,3,3);
%[tn, qn1, qn2]=quantreg0(200,15, zeros(15,1),2,3,3);
t(k)=tn;
q(k)=qn1;
r(k)=qn2;
end

 delete(gcp('nocreate'))

 [sum(t>q)/300 sum(t>r)/300]

[superq(t,q) superq(t,r)]