function level=superq(t,q)
len=length(q);
q1=sort(q);
p=zeros(1,len);
for k=1:len 
    p(k)=mean(t>q1(len-k+1));
end
fdr=find(p<=0.01*(1:len)/len);

if isempty(fdr)
    level=mean(t>min(q));
else
    index=fdr(end);
    qstar=q1(len-index+1);
    level=mean(t>qstar);
end

if level<=1/len
    level=mean(t>min(q));
end



    