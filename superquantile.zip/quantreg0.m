 function [tn, qn1, qn2]=quantreg0(n,d, beta, model,error,xdesign)
%n=200;d=15;B=1000;reps=200 to repeat this code;
%generate x

rng('shuffle');B=1000; 
s=zeros(d,d);

switch xdesign
    case 1
        x=randn(n,d);
    case 2
        sigma_diag=rand(1,d)/2+0.5;
        for i=1:(d-1)
            for k=(i+1):d
                s(i,k)=0.5^abs(i-k)*sqrt(sigma_diag(i)*sigma_diag(k));
                s(k,i)=s(i,k);
            end
            s(i,i)=sigma_diag(i);
        end
        s(d,d)=sigma_diag(d);
        r=chol(s);
        x=randn(n,d)*r;
    case 3
        sigma_diag=rand(1,d)/2+0.5;
        for i=1:(d-1)
            for k=(i+1):d
                s(i,k)=0.5*sqrt(sigma_diag(i)*sigma_diag(k));
                s(k,i)=s(i,k);
            end
            s(i,i)=sigma_diag(i);
        end
        s(d,d)=sigma_diag(d);
        r=chol(s);
        x=randn(n,d)*r;
end
%generate errors
e=zeros(1,n);
 switch error
     case 1
         e=trnd(2,1,n);
     case 2
         z=randn(1,n);
         a=rand(1,n);
         e=(-1+z).*(a>=0.5)+(1+z).*(a<0.5);
     case 3
         z=randn(1,n);
         a=rand(1,n);
         e=(-1+z).*(a>=0.1)+(1+z).*(a<0.1);
 end
 %generate y
 %beta0=2;
 %beta=2*ones(d,1);
 y=zeros(n,1);
 switch model
     case 1
         y=x*beta+e';
     case 2
         y=x*beta+e'.*(2*exp(x(:,1))./(1+exp(x(:,1))));
 end
%setup pinball losses
 myfun=@(b, yy,xx,ww) (ww*((yy-xx*b).*(0.5-(yy-xx*b<0))));
%yy=y;xx=x;


fun=@(b) myfun(b,y,x,ones(1,n)); 

options=optimset('MaxFunEvals',30000, 'MaxIter',30000);

tn1=myfun(zeros(d,1),y,x,ones(1,n));
[m,tn2]=fminsearch(fun,zeros(d,1),options);
tn=tn1-tn2;

perquant=zeros(1,B);normquant=zeros(1,B);

for k=1:B
    a=rand(1,n);

    mbperfun=@(c) myfun(c,y,x, 2*(a>0.5)); 
   
ptn1=myfun(zeros(d,1),y,x,2*(a>0.5));

    [~,ptn2]=fminsearch(mbperfun,zeros(d,1), options);
    perquant(k)=mbperfun(m)-ptn2;
%disp(ptn1-ptn2)
%disp((mbperfun0(m0)-mbperfun(m)))


    mbnormfun=@(c) myfun(c,y,x,-log(a));
    
    ntn1=myfun(zeros(d,1),y,x,-log(a));

    [~,ntn2]=fminsearch(mbnormfun,zeros(d,1), options);
    normquant(k)=mbnormfun(m)-ntn2;
end


qn1_sorted=sort(perquant);
qn1=qn1_sorted(990);
qn2_sorted=sort(normquant);
qn2=qn2_sorted(990);

